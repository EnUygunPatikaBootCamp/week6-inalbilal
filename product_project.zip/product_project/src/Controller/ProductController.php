<?php
namespace App\Controller;

use App\Entity\Product;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\Routing\Annotation\Route;


class ProductController extends AbstractController
{

    /**
     * @Route("/product", methods={"POST"})
     */
    public function productCreate(ManagerRegistry $doctrine): Response
    {
        $entityManger = $doctrine->getManager();
        $product = new Product();

        $tarih = new \DateTime();
        $product->setUrunAdi("Telefon")
            ->setUrunAciklamasi("Pahalı telefon")
            ->setUrunAdedi(1)
            ->setUrunFiyati(10.920)
            ->setUrunKayitTarihi($tarih);

        $entityManger->persist($product);
        $entityManger->flush();

        return new JsonResponse(["result" => "Ürün Başarıyla eklendi"]);

    }


    /**
     * @Route("/product", methods={"GET"})
     */
    public function productAllList(ManagerRegistry $doctrine): Response
    {
        $product = $doctrine->getRepository(Product::class)->findAll();

        if (!$product) {
            return new JsonResponse(["result" => "Listelenecek ürünler bulunamadı!"], Response::HTTP_NOT_FOUND);
        }

        $arrayProduct = array();

        foreach($product as $items) {
            $arrayProduct[] = array(
                "UrunId" => $items->getId(),
                "UrunAdi" => $items->getUrunAdi(),
                "UrunAciklamasi" => $items->getUrunAciklamasi(),
                "UrunFiyati" => $items->getUrunFiyati(),
                "UrunKayitTarihi" => $items->getUrunKayitTarihi()
            );
        }
        return new JsonResponse($arrayProduct, Response::HTTP_OK);

    }


    /**
     * @Route("/product/{id}", methods={"GET"})
     */
    public function productList(ManagerRegistry $doctrine, int $id): Response
    {
        $product = $doctrine->getRepository(Product::class)->find($id);

        if (!$product) {
            return new JsonResponse(["result" => "Listelenecek ürün bulunamadı!"], Response::HTTP_NOT_FOUND);
        }

        return new JsonResponse([
            "UrunId" => $product->getId(),
            "UrunAdi" => $product->getUrunAdi(),
            "UrunAciklamasi" => $product->getUrunAciklamasi(),
            "UrunFiyati" => $product->getUrunFiyati(),
            "UrunKayitTarihi" => $product->getUrunKayitTarihi()

        ]);

    }



    /**
     * @Route("/product/{id}", methods={"PUT"})
     */
    public function productUpdate(ManagerRegistry $doctrine, int $id): Response
    {
        $entityManager = $doctrine->getManager();
        $product = $entityManager->getRepository(Product::class)->find($id);

        if (!$product) {
            return new JsonResponse(["result" => "Güncellenecek ürün bulunamadı!"], Response::HTTP_NOT_FOUND);
        }
        $product->setUrunAdi('Iphone 11');
        $entityManager->flush();

        return new JsonResponse([
            "result" => "Güncelleme başarılı!",

        ]);
    }


    /**
     * @Route("/product/{id}", methods={"DELETE"})
     */
    public function productRemove(ManagerRegistry $doctrine, int $id): Response
    {
        $entityManager = $doctrine->getManager();
        $product = $entityManager->getRepository(Product::class)->find($id);

        if (!$product) {
            return new JsonResponse(["result" => "Silinecek ürün bulunamadı!"], Response::HTTP_NOT_FOUND);
        }
        $entityManager->remove($product);
        $entityManager->flush();

        return new JsonResponse([
            "result" => "Ürün başarıyla silindi",

        ]);
    }

}